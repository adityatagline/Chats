import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import React from "react";
import { memo } from "react";
import Icon from "@expo/vector-icons/Ionicons";

const Settings = ({
  disableBackButton = false,
  rightButton,
  middleComponenet,
  navigationObj,
  backButtonProps,
  backButtonStyle,
}) => {
  return (
    <View style={styles.mainDiv}>
      {!disableBackButton && (
        <TouchableOpacity
          onPress={() => navigationObj.goBack()}
          style={[styles.backButtonDiv, backButtonStyle]}
        >
          <Icon
            name={backButtonProps.name}
            size={backButtonProps.size}
            color={backButtonProps.color}
            style={[styles.backButtonIcon]}
          />
          <Text style={styles.backButtonLabel}>
            {!!backButtonProps.backScreen ? backButtonProps.backScreen : "Back"}
          </Text>
        </TouchableOpacity>
      )}
      {!!middleComponenet && middleComponenet}
      {!!rightButton && rightButton}
    </View>
  );
};

export default memo(Settings);

const styles = StyleSheet.create({
  mainDiv: {
    // backgroundColor: "red",
    // marginTop: "50%",
  },
  backButtonIcon: {
    // backgroundColor: "lightblue",
    // paddingHorizontal: "3%",
  },
  backButtonDiv: {
    // backgroundColor: "lightblue",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    marginLeft: "7%",
    marginVertical: "2%",
    marginBottom: "3%",
  },
  backButtonLabel: {
    fontWeight: "bold",
  },
});
