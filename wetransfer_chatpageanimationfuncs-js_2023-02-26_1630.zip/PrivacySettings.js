import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ScrollView,
  TouchableOpacity,
  NativeModules,
  Appearance,
} from "react-native";
import React from "react";
import PageHeading from "./PageHeading";
import Icon from "@expo/vector-icons/Ionicons";
import { StatusBarHeight } from "../src/styles/commonStyles";

export default PrivacySettings = () => {
  const PageName = () => {
    return <Text style={styles.pageHeading}>Privacy</Text>;
  };

  const PageNameSecurity = () => {
    return (
      <Text style={[styles.pageHeading, { marginTop: "5%" }]}>Security</Text>
    );
  };

  const styles = StyleSheet.create({
    mainDiv: {
      marginTop: StatusBarHeight,
    },
    pageHeading: {
      // backgroundColor: "yellow",
      // flex: 1,
      // textAlign: "center",
      marginLeft: "10%",
      fontSize: 25,
      fontWeight: "bold",
    },
    settingItem: {
      // backgroundColor: "yellow",
      flexDirection: "row",
      marginVertical: "1%",
      paddingVertical: "4%",
      marginHorizontal: "1%",
      borderRadius: 15,
      paddingHorizontal: "7%",
      alignItems: "center",
    },
    settingItemIcon: {
      paddingRight: "5%",
    },
    settingItemLabel: {
      // fontWeight: "bold",
    },
    listDiv: {
      marginTop: "5%",
    },
  });

  const SettingItem = ({
    title,
    onPress,
    customContainerStyle,
    customLabelStyle,
    itemIcon,
  }) => {
    return (
      <TouchableOpacity
        onPress={onPress}
        style={[styles.settingItem, customContainerStyle]}
      >
        <Icon name={itemIcon} size={30} style={styles.settingItemIcon} />
        <Text style={[styles.settingItemLabel, customLabelStyle]}>{title}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.mainDiv}>
      <PageHeading
        middleComponenet={<PageName />}
        backButtonProps={{
          name: "chevron-back",
          size: 30,
          color: "black",
          backScreen: "Settings",
        }}
      />
      <ScrollView style={styles.listDiv}>
        <SettingItem
          title={"Blocked Contacts"}
          itemIcon={"remove-circle-outline"}
        />
        <SettingItem title={"Status settings"} itemIcon={"eye"} />
      </ScrollView>
      <PageHeading middleComponenet={<PageNameSecurity />} disableBackButton />
      <ScrollView style={styles.listDiv}>
        <SettingItem title={"Change password"} itemIcon={"sync"} />
      </ScrollView>
    </View>
  );
};
